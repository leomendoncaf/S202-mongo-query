# S202

## Material:
https://determined-zebra-b82.notion.site/Bancos-de-dados-II-580c835e83554a9b9300558b4b4b87b3


## Como executar?
3. Instale as dependências:
    ```sh
    pip install -r requirements.txt
    ```
4. execute o arquivo `main.py`
    ```sh
    python main.py
    ```
